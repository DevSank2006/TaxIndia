import { useState } from 'react';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Benefits from './components/Benefits.jsx';
import Services from './components/Services.jsx';
import Banking from './components/Banking.jsx';
import Calculator from './components/Calculator.jsx';
import WhyUs from './components/WhyUs.jsx';
import Reviews from './components/Reviews.jsx';
import Advisor from './components/Advisor.jsx';
import Contact from './components/Contact.jsx';
import FAQ from './components/FAQ.jsx';
import Footer from './components/Footer.jsx';
import WhatsAppButton from './components/WhatsAppButton.jsx';

export default function App() {
  const [selectedService, setSelectedService] = useState('GST Registration');
  return <>
    <Header />
    <main>
      <Hero onChooseService={setSelectedService} />
      <Benefits />
      <Services onApply={setSelectedService} />
      <Banking onApply={setSelectedService} />
      <Calculator />
      <WhyUs />
      <Reviews />
      <Advisor />
      <Contact selectedService={selectedService} />
      <FAQ />
    </main>
    <Footer />
    <WhatsAppButton />
  </>;
}
