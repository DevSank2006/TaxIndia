import ServiceDetailsModal from './ServiceDetailsModal.jsx';
import ServiceApplyModal from './ServiceApplyModal.jsx';

export default function ServiceActionModal({ service, mode, onClose }) {
  return mode === 'details'
    ? <ServiceDetailsModal service={service} onClose={onClose}/>
    : <ServiceApplyModal service={service} onClose={onClose}/>;
}
