import { Quote, Star } from 'lucide-react';
export default function ReviewCard({ review }) {
  return <article className="review-card"><div className="review-card-head"><span className="quote-icon"><Quote size={18}/></span><span className="review-date">{review.date}</span></div><div className="review-stars"><Star/><Star/><Star/><Star/><Star/></div><p className="review-quote">“{review.quote}”</p><div className="review-service">SERVICE <b>{review.service}</b></div><div className="review-person"><span className="review-initials">{review.name.split(' ').map(w=>w[0]).slice(0,2).join('')}</span><span><b>{review.name}</b><small>{review.role}</small></span><span className="verified">✓ VERIFIED</span></div></article>;
}
