import { BadgeIndianRupee, Clock3, UserRoundCheck, LockKeyhole } from 'lucide-react';
const items = [
  { icon: BadgeIndianRupee, title: 'No Advance Payment', text: 'First work completed, then you pay. Zero financial risk!' },
  { icon: Clock3, title: 'Fastest Turnaround', text: 'GST & Registrations delivered in 24 to 48 Hours.' },
  { icon: UserRoundCheck, title: 'Senior CA Support', text: 'Every file handled & verified by experienced CAs.' },
  { icon: LockKeyhole, title: '100% Confidential', text: 'Encrypted document storage & strict privacy guarantee.' },
];
export default function Benefits() {
  return <section className="benefits-section"><div className="container benefit-grid">{items.map(({ icon: Icon, title, text }, i) => <article className="benefit-item" key={title}><span className={`benefit-icon benefit-icon-${i}`}><Icon size={21} /></span><div><h3>{title}</h3><p>{text}</p></div></article>)}</div></section>;
}
