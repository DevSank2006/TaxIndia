import { ArrowUpRight, Check, Landmark, CreditCard, BriefcaseBusiness, WalletCards } from 'lucide-react';
const icons = [Landmark, CreditCard, BriefcaseBusiness, WalletCards];
export default function BankingCard({ item, index, onApply }) {
  const Icon = icons[index];
  return <article className="banking-card"><div className="banking-card-head"><span className="bank-icon"><Icon size={21} /></span><span className="bank-eyebrow">{item.tag}</span></div><h3>{item.title}</h3><p>{item.text}</p><ul>{item.points.map(point => <li key={point}><Check size={15} />{point}</li>)}</ul><div className="bank-partners"><small>PARTNER NETWORK</small><div>{item.partners.map(bank => <span key={bank}>{bank}</span>)}</div></div><button className="bank-apply" onClick={() => onApply(item.title)}>Explore this option <ArrowUpRight size={16} /></button></article>;
}
