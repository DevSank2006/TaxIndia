import { ArrowRight, ArrowUpRight, Check, ShieldCheck, Sparkles, Phone, MessageCircle } from 'lucide-react';
import LeadForm from './LeadForm.jsx';
import { whatsappLink } from '../utils/whatsapp.js';

export default function Hero() {
  return <section className="hero-section"><div className="hero-grain" />
    <div className="container hero-layout">
      <div className="hero-copy">
        <div className="hero-tag"><Sparkles size={14} /> OFFER ONLY FEW TIME &nbsp; <span>◉ NO ADVANCE MONEY - FIRST WORK THEN PAYMENT</span></div>
        <h1>India's No.1 Online<br /><span>Tax &amp; Business Services</span><br/>Company</h1>
        <p className="hero-intro">Register your Business, File GST &amp; Income Tax, Get Food Licenses &amp; Business Loans online anywhere in India with expert Senior Chartered Accountants.</p>
        <div className="hero-stats"><div><b>12.5+ LAKH</b><small>Trusted Customers</small></div><div><b>ZERO RISK</b><small>First Work Then Money</small></div><div><b>24-48 HOURS</b><small>Fast Turnaround</small></div></div>
        <div className="hero-actions"><a className="button button-lime" href="#contact">GET STARTED NOW <ArrowRight size={17} /></a><a className="hero-whatsapp" href={whatsappLink('Hello TAX INDIA, I want to apply for GST Registration. Please contact me.')} target="_blank" rel="noreferrer"><MessageCircle size={18}/> WhatsApp Us Now</a></div>
        <div className="hero-direct"><span>Direct Senior CA Helpline:</span> <a href="tel:+917814006162"><Phone size={15}/> +91 7814006162</a><small>⭐ 4.9/5 Rating · Based on 85,000+ Verified Reviews</small></div>
        <div className="hero-proof"><div className="avatar-stack"><span>RK</span><span>AS</span><span>VM</span><span>+12k</span></div><div><div className="stars">★★★★★ <b>4.9/5</b></div><small>Trusted by businesses across India</small></div><span className="proof-separator" /><div className="proof-shield"><ShieldCheck size={23} /><span><b>Zero advance</b><small>Pay after the work</small></span></div></div>
      </div>
      <div className="hero-form-wrap"><div className="form-orbit orbit-one"/><div className="form-orbit orbit-two"/><LeadForm /></div>
    </div>
    <div className="container hero-bottom"></div>
  </section>;
}
