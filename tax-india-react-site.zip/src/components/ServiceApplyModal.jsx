import { useState } from 'react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import ServiceModalFrame from './ServiceModalFrame.jsx';
import ServiceApplicationSuccess from './ServiceApplicationSuccess.jsx';
import { services } from '../data/services.js';
import { createLeadReference } from '../utils/leadReference.js';

export default function ServiceApplyModal({ service, onClose }) {
  const [lead, setLead] = useState(null);
  const [fields, setFields] = useState({ name: '', mobile: '', service: service.name });
  const change = event => setFields(current => ({ ...current, [event.target.name]: event.target.value }));
  const submit = event => {
    event.preventDefault();
    setLead({ ...fields, name: fields.name.trim(), mobile: fields.mobile.trim(), reference: createLeadReference() });
  };

  return <ServiceModalFrame className="service-modal-apply" onClose={onClose}>
    {lead ? <ServiceApplicationSuccess lead={lead} onClose={onClose}/> : <>
      <span className="service-modal-eyebrow">NO ADVANCE MONEY - FIRST WORK THEN PAYMENT</span>
      <h2 id="service-modal-title">Apply for {service.name}</h2>
      <p className="service-modal-description">Enter your details for instant CA consultation &amp; document checklist.</p>
      <form className="service-apply-form" onSubmit={submit}>
        <label>FULL NAME<input name="name" value={fields.name} onChange={change} placeholder="e.g. Ankit Sharma" autoComplete="name" required/></label>
        <label>MOBILE NUMBER (WHATSAPP) *<span className="service-mobile-field"><b>+91</b><input name="mobile" value={fields.mobile} onChange={change} placeholder="9876543210" autoComplete="tel-national" inputMode="numeric" pattern="[6-9][0-9]{9}" title="Enter a valid 10-digit Indian mobile number" required/></span></label>
        <label>SELECTED SERVICE<select name="service" value={fields.service} onChange={change}>{services.map(item => <option key={item.name} value={item.name}>{item.name} (₹{item.price.toLocaleString('en-IN')})</option>)}</select></label>
        <button className="service-modal-primary" type="submit">SUBMIT &amp; CALL ME BACK <ArrowRight size={18}/></button>
      </form>
      <div className="service-form-privacy"><ShieldCheck size={17}/> Zero advance payment · Guaranteed privacy</div>
    </>}
  </ServiceModalFrame>;
}
