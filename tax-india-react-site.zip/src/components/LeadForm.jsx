import { ArrowRight, LockKeyhole } from 'lucide-react';
import { services } from '../data/services.js';

export default function LeadForm({ compact = false }) {
  return <form className={`lead-form ${compact ? 'lead-form-compact' : ''}`} onSubmit={e => { e.preventDefault(); window.location.href = '#contact'; }}>
    <div className="form-kicker">70% SPECIAL DISCOUNT</div>
    <h3>{compact ? 'Request a quick callback' : 'Fast Track Application'}</h3>
    <p>Enter details to get an instant CA Callback &amp; Quote. No payment needed upfront!</p>
    <label>YOUR FULL NAME<input type="text" placeholder="e.g. Ramesh Kumar" required /></label>
    <label>MOBILE NUMBER (WHATSAPP) *<div className="phone-input"><span>+91</span><input type="tel" placeholder="9876543210" required /></div></label>
    <label>SELECT SERVICE REQUIRED<select defaultValue="GST Registration">{services.map(s => <option key={s.name} value={s.name}>{s.name} (Starts ₹{s.price})</option>)}<option>Savings / Current Account Opening</option><option>Business Loan / Mudra Loan</option></select></label>
    <button type="submit" className="button button-primary form-submit">SUBMIT &amp; CALL ME BACK <ArrowRight size={17} /></button>
    <div className="form-assurance"><LockKeyhole size={14} /> NO ADVANCE PAYMENT — First Work Then Payment &nbsp; · &nbsp; 🔒 100% Confidential &amp; Confidentiality Assured</div>
  </form>;
}
