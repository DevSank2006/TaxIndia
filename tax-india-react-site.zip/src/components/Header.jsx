import { useState } from 'react';
import { Menu, X, Phone, MessageCircle, ArrowUpRight } from 'lucide-react';
import Logo from './Logo.jsx';
import { whatsappLink } from '../utils/whatsapp.js';

const links = [['Services', '#services'], ['Banking', '#banking'], ['Calculators', '#calculators'], ['AI Advisor', '#ai-advisor'], ['Why Us', '#why-us'], ['Reviews', '#testimonials'], ['FAQ', '#faq']];
export default function Header() {
  const [open, setOpen] = useState(false);
  return <>
    <div className="topline"><div className="container topline-inner"><span><b>NO ADVANCE MONEY</b> <i>⚡</i> First Work, Then Payment — 100% Work Satisfaction Guaranteed!</span><div><a href="tel:+917814006162"><Phone size={13} /> Call: +91 7814006162</a><span className="top-divider">|</span><a href={whatsappLink()} target="_blank" rel="noreferrer"><MessageCircle size={13} /> WhatsApp Us</a></div></div></div>
    <header className="site-header" id="top"><div className="container header-inner">
      <Logo />
      <nav className={open ? 'nav-open' : ''} aria-label="Main navigation">{links.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>)}<a className="mobile-call" href="tel:+917814006162"><Phone size={16} /> +91 78140 06162</a></nav>
      <div className="header-actions"><a className="header-phone" href="tel:+917814006162"><Phone size={15} /> <span>+91 7814006162</span></a><a href={whatsappLink()} target="_blank" rel="noreferrer" className="button header-whatsapp"><MessageCircle size={16}/> WhatsApp</a><a href="#contact" className="button button-primary header-cta">Get Started <ArrowUpRight size={16} /></a></div>
      <button className="menu-toggle" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
    </div></header>
  </>;
}
