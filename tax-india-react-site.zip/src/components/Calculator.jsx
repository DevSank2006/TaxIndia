import { useMemo, useState } from 'react';
import SectionHeading from './SectionHeading.jsx';
import { estimateIncomeTax } from '../utils/tax.js';

const money = value => `₹${Math.round(value).toLocaleString('en-IN')}`;

export default function Calculator() {
  const [mode, setMode] = useState('income');
  const [income, setIncome] = useState(850000);
  const [incomeType, setIncomeType] = useState('salary');
  const [invest, setInvest] = useState(150000);
  const [health, setHealth] = useState(25000);
  const [gstAmount, setGstAmount] = useState(18000);
  const [rate, setRate] = useState(18);
  const estimate = useMemo(() => estimateIncomeTax({ income, investment: invest, health, incomeType }), [income, invest, health, incomeType]);
  const savings = Math.abs(estimate.oldTax - estimate.newTax);
  const recommendation = estimate.newTax <= estimate.oldTax ? 'New Tax Regime' : 'Old Tax Regime';

  return <section className="section calculator-section" id="calculators"><div className="container calculator-layout">
    <div className="calculator-intro"><SectionHeading eyebrow="FREE CA CALCULATORS" title="Smart Tax & Business Calculators" description="Estimate income tax or work out the GST amount as you enter your figures."/></div>
    <div className="calc-tabs"><button className={mode === 'income' ? 'active' : ''} onClick={() => setMode('income')}>Income Tax (ITR) Calculator</button><button className={mode === 'gst' ? 'active' : ''} onClick={() => setMode('gst')}>GST Tax Calculator</button></div>
    <div className="calculator-card">{mode === 'income' ? <div className="calc-split">
      <div className="calc-fields"><h3>Enter Income &amp; Deductions</h3>
        <label>Income type</label><select value={incomeType} onChange={event => setIncomeType(event.target.value)}><option value="salary">Salary income</option><option value="business">Business / professional income</option></select>
        <label>Annual gross income (₹)</label><input type="number" min="0" value={income} onChange={event => setIncome(event.target.value)} />
        <label>Section 80C investments (max ₹1.5L)</label><input type="number" min="0" max="150000" value={invest} onChange={event => setInvest(event.target.value)} />
        <label>Section 80D health insurance (max ₹50,000)</label><input type="number" min="0" max="50000" value={health} onChange={event => setHealth(event.target.value)} />
      </div>
      <div><div className="tax-results"><div><span>New tax regime estimate</span><b>{money(estimate.newTax)}</b></div><small className="tax-base">Taxable income: {money(estimate.newTaxable)}</small><div><span>Old tax regime estimate</span><b>{money(estimate.oldTax)}</b></div><small className="tax-base">Taxable income: {money(estimate.oldTaxable)}</small><p>💡 {recommendation} is lower by {money(savings)} for these inputs.</p></div><small className="tax-estimate-note">Indicative estimate for FY 2025–26 (AY 2026–27). Special-rate income, surcharge and other adjustments are not included.</small><a href="#contact" className="calc-cta">File Your ITR with Expert CA (Starts ₹299)</a></div>
    </div> : <div className="calc-fields gst-calculator"><h3>Calculate GST</h3><label>Amount before GST (₹)</label><input type="number" min="0" value={gstAmount} onChange={event => setGstAmount(event.target.value)} /><label>GST rate</label><select value={rate} onChange={event => setRate(Number(event.target.value))}>{[5, 12, 18, 28].map(value => <option key={value} value={value}>{value}%</option>)}</select><div className="tax-results"><div><span>GST amount</span><b>{money(Number(gstAmount) * rate / 100)}</b></div><div><span>Total including GST</span><b>{money(Number(gstAmount) * (1 + rate / 100))}</b></div></div></div>}</div>
  </div></section>;
}
